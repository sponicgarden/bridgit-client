# Create and validate a Bridgit applet offline

Unzip this kit into an empty directory. Java 17 or newer runs the validator on
macOS, Linux or Windows. Optional local asset packing uses Python 3.9 or newer.
Authoring and static validation work offline. For an installed Android release,
download this ZIP from the matching public Git release tag (the repository path
is `site-content/public/applets/authoring/bridgit-applet-authoring-v1.zip`).
The checkout command `python3 tools/build-applet-authoring-kit.py --verify`
checks its runtime source hashes and every archived file. Offline,
`kit-manifest.json` identifies the validator SHA-256 and device API revision.

1. Choose a file in `examples/` with the behavior you need. The desk lamp
   example takes a picture, asks Clef a question and shows a conditional notice.
   Copy the example to `applet.json`. Give it its own ID and name. Use
   `bridgit.package.v1` as the adapter for new portable packages.
2. Read `package-guide.md` for the envelope and `cards.md` for card and table
   syntax. Choose the trigger in `workflow-trigger.schema.json`. Each trigger has a copyable JSON example, closed fields and bounds. Check filled steps against `workflow-step.schema.json`. Use `workflow-steps.md` and `flow-contract.json` for step inputs, results, scopes and
   limits. Inspect `services.json` for service choices and `endpoints.json`
   for the method, path, required capability and parameters of device actions.
   For Apple targets, check the card actions in `workflow-steps.md`.
   Before editing an installed personal edition, follow `modifying-applets.md`.
   A hosted model also needs a nonempty `permissions.remote` disclosure and
   `data_policy.device_only.remote_models: true`. Include the full data policy
   shown in the desk lamp example. The registry defaults hosted model access to
   off when the author omits it. Owner approval and configured limits are still
   required for execution. For Android watches, set `camera` to the primary source
   and `additional_cameras` to up to seven other sources to sample in order.
   A `lan:<id>` comes from the host's authenticated `GET /v1/lan-cameras`.
   Declare `lan_camera` in `permissions.optional` if the user can choose a LAN
   camera. The resolved config determines whether the owner must approve that grant.
   For sound watches, `request.sound.sources` selects `builtin` or enrolled LAN
   microphone IDs. A camera microphone additionally requires `lan_camera_audio`.
   The package contract gives bounds, defaults and the meaning of an empty list.
3. If the manifest references local files, run
   `python3 pack-applet.py manifest.json > applet.json`. Keep the source and
   output filenames distinct. Self-contained examples can skip this step.
4. Run `java -jar validate-applet.jar applet.json`. Success prints JSON with
   `valid: true`, the package digest and derived scopes. A rejected package
   prints `valid: false` with a diagnostic and exits with status 1. Fix the
   source, repack if needed and rerun. These checks use the Android runtime's
   parsing and validation code. Read the report's `not_checked` fields and the
   platform limits in `package-contract.md` before promising device behavior.
5. Keep the source and packed JSON. When the owner wants to publish, follow
   `library-management.md` for role requirements, immutable revisions, private
   forks and idempotent retries. Live service calls require the installed
   host's support, the owner's grants and any applicable budget.

The validator incorporates portions of Bridgit and Kotlin standard library
(Copyright JetBrains s.r.o. and Kotlin Programming Language contributors,
Apache License 2.0, included in LICENSE) and the public-domain JSON-java parser.

Read the validator's `warnings` even when `valid` is true. For hosted
`ask_model` steps, disclose the outgoing data in `permissions.remote` and set
`data_policy.device_only.remote_models` to true. The registry defaults this
field to false. The owner still approves each native Apple Clef submission.
