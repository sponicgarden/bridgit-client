# Applet cards: built-in pieces and an on-phone table

Status: phase 2 spec (5 Nov 2026). Builds on phase 1, [applet-flows.md](applet-flows.md) (flow steps in the
workflow engine). Phase 3 (one action vocabulary everywhere) gets its own spec.

## Why

An agent building an applet today writes, or copies, a whole web page for its card. Every recipe card is a
copy of the same ~14 KB shell (`site-content/content/builder/recipe-card.html`) with five hard-coded modes
(`watch`, `ocr`, `voice`, `lan`, `weather`), and a card asset may be at most 16 KB. So:

- A new kind of card means editing a 14 KB script, inside a 16 KB limit, with no room left.
- The agent spends its effort on layout, escaping, freshness timers and button wiring, not on what the
  applet should show.
- Cards can't show photos or videos well (the card sandbox only allows inline `data:` images and blocks
  media), and can't read the applet's own flow runs at all (`Bridgit.act` reaches only `/v1/` endpoints).
- Anything the owner wants to keep (a receipt, a voice note) has nowhere to go on the phone. The shell
  sends it to the agent with `Bridgit.respond`, and the agent has to store it on its own server.

Phase 2 fixes this with two things:

1. **Card pieces.** The package lists pieces (header, metrics, gallery, table, buttons...) and where each
   gets its data. The phone draws them in Bridgit's own style. No HTML, no CSS, no script.
2. **An on-phone table.** A flow step `record` (and a card button) appends a typed row. The owner can see
   and delete rows; the card's `table` piece shows them; the installing agent can read them if the owner
   agreed.

Plus one clean-up: `POST /v1/applets/validate` fills in the package sections the phone ignores, so agents
stop copying them.

## Decision: pieces are drawn natively

The phone draws pieces with its own Android views, inside the existing card screen. There is no shared
HTML renderer.

| | Native views (chosen) | One shared HTML renderer shipped in the app |
|---|---|---|
| Photos and video | The app's own image loader and video player, straight from phone storage | The card sandbox allows only `data:` images and no media. Every photo would cross the bridge as base64 (replies over 64 KB come back as a size only), and video would need the sandbox opened up |
| Applet data (flow runs, tables, kept photos) | Read in the app, no endpoint needed | Needs new card-callable endpoints for each, each one a new surface to secure |
| Look | Same fonts, colours, dark mode, text size and TalkBack as the rest of Bridgit, for free | Has to copy Bridgit's style into CSS and keep it in step |
| Safety | No agent script runs at all | Still a WebView running a script; a renderer bug is a script-injection risk |
| Speed | No WebView start-up; cards open instantly in the Applets tab | A WebView per card |
| Cost | Each piece is written once in Kotlin, plus a look-alike preview for the website | One renderer, usable on the website as-is |

The website gets a small look-alike preview (built by `site-content/scripts/builder-recipes.mjs` from the same
JSON) so recipe pages and the builder can show what a card will look like. The preview is not the
contract; the phone is.

Custom HTML stays as the escape hatch: `ui.card.asset` works exactly as today. A card is either pieces or
custom HTML, not both (mixing is in "Not in phase 2").

## Card pieces

### Where they go

`ui.card` gets `pieces` (and `sources`) instead of `asset`:

```json
"ui": {
  "card": {
    "title": "Pet activity monitor",
    "sources": {"activity": {"watch": {"$watch": "main"}, "read": "tally"}},
    "fresh_s": 120,
    "pieces": [
      {"type": "header", "text": "A little window into your pet's day."},
      {"type": "metrics", "items": [
        {"label": "Observed minutes", "value": {"$source": "activity.today.watched_minutes"}},
        {"label": "Readings", "value": {"$source": "activity.today.checks"}}]},
      {"type": "buttons", "items": [{"label": "Pause", "do": {"pause_applet": true}}]}
    ]
  }
}
```

- `title`: required, as today.
- Exactly one of `asset` (custom HTML, as today) or `pieces` (1-24 pieces). `data` belongs to `asset`
  cards only.
- `sources`: 0-8 named data sources (below). Names are lowercase, like step ids.
- `fresh_s`: optional, 30-86400. A source whose newest data is older than this marks the card stale.
- The `ui.card` object is at most 16 KB, the same as a card asset. Real cards use 1-4 KB.

The phone posts the card as an interaction of the new kind `pieces` (the card a custom-HTML applet posts
stays kind `html`). It is renewed, paused and removed with the applet exactly like today's card, and it
works in card stacks. An agent can also post a `pieces` card itself with `POST /v1/interactions`
(`kind: "pieces"`, same fields): its sources may only name the agent's own watches and calls.

### Data sources

A source is one place the card reads from. Pieces point into a source with `{"$source": "<name>.<path>"}`.

| Source | Shape | Gives | Updates |
|---|---|---|---|
| Watch tally | `{"watch": {"$watch": "main"}, "read": "tally"}` | the `GET /v1/watches/{id}/tally` reply: `today.checks`, `today.watched_minutes`, `today.labels`, `episodes`... | live while the card is open |
| Watch status | `{"watch": {"$watch": "main"}, "read": "status"}` | the `GET /v1/watches/{id}` reply: `checks`, `matches`, `last_check`, `recent_checks`, `people`... | live |
| Flow runs | `{"runs": "workflow", "limit": 10}` | the applet's own workflow runs, newest first, as `workflow.runs` returns them (`items[]` with `status`, `started_at`, `steps[]`) | live |
| Last step result | `{"runs": "workflow", "step": "look"}` | the `result` of step `look` in the newest run where it ran (`ok`) | live |
| Table | `{"table": "receipts", "limit": 20}` | rows of an on-phone table (below), newest first (`items[]`, `count`) | live |
| Kept photos | `{"photos": "shot", "limit": 12}` | photos kept by the flow's `photo` step `shot` (below), newest first | live |
| Call | `{"call": {"method": "GET", "path": "/v1/weather", "query": {"hours": 24}}}` | the reply of one read-only endpoint, run as the applet | when the card opens, on Refresh, and every `every_s` (60-3600) while it is open, if set |
| Mode | `{"mode": true}` | the phone's mode: `mode`, `label`, `since`, `set_by`, `modes` (docs/applet-reach.md D2) | live |
| Button reply | `{"reply": "scan"}` | the reply of the button whose `into` is `scan`, until the card closes | when that button runs |

Rules:

- A call source must be a `GET` endpoint the applet's permissions cover (they're derived as today; a call
  to `/v1/weather` adds `weather`). It runs through the same check as `Bridgit.act`
  (`interact/CardActions.kt`) and the agent's grants, switches and limits apply. No call source runs while
  the card is closed: nothing polls in the background.
- `$watch` now also works in `ui.card.sources` and in buttons, not only in `ui.card.data`.
- `{"$source": ...}` is a whole-value reference, the same rule as `$input`, `$watch` and phase 1's
  `$step`: the node is replaced by the value, never spliced into text or a request. A path that doesn't
  exist gives `null`, which a piece shows as its `empty` text (default "—").
- Unknown source names, unknown table or step ids, and a `photos` source on a step that doesn't keep
  photos are validation errors.

### Text

Every text field (`text`, `label`, `title`, `note`, `empty`...) takes a string or an array of parts
(strings and `$source` references), joined into one string, at most 1024 characters. Text is always drawn
as plain text, never as HTML or a link.

### Formats

Values are shown with an optional `format`:

`text` (default), `number` (grouped digits), `minutes` ("1 h 20 min"), `duration_s`, `time` ("5 Nov,
14:05", from an ISO time or epoch ms), `ago` ("3 min ago"), `date`, `percent` (0-1 → "40%"), `celsius`,
`money` (with `currency`, a 3-letter code or `{"$source": ...}`), `yes_no`, and `words` with a `words`
map that turns codes into plain words (`{"true": "Image changed", "false": "No change"}`; values not in the
map show as they are).

### Showing a piece only sometimes

Every piece may have `only_if`, the same tests as phase 1 with `source` instead of `step`:
`{"source": "activity.today.checks", "at_least": 1}`. A piece whose test is false is not drawn.

### The pieces

| Piece | Fields | Draws |
|---|---|---|
| `header` | `title` (default: the card title), `text`, `eyebrow` | the card's title block |
| `status` | `text`, `tone`: `info` \| `ok` \| `warn` \| `bad` | one status line with a coloured pill |
| `text` | `text` | a plain paragraph |
| `note` | `text` | small grey text, for limits ("Sampled photos, not continuous coverage") |
| `metrics` | `items` (1-6): `label`, `value`, `format`, `unit`, `empty` | tiles, two per row |
| `gallery` | `photos` (a `photos` source or an array of kept photo refs), `caption` (a key in each item, e.g. `taken_at`), `caption_format`, `limit` (1-24), `empty` | a grid of thumbnails; a tap opens the photo full screen |
| `video` | `video` (a video ref), `poster`, `caption`, `empty` | a player; nothing plays until tapped, sound starts muted |
| `table` | `rows` (a `table` source, any array, or an object whose keys become rows), `columns` (1-6): `key` (`$key` for an object's keys), `label`, `format`; `limit` (1-50), `empty`, `owner_delete` (default `false`) | rows and columns; a tap shows the whole row; with `owner_delete` a long press offers Delete (on-phone tables only) |
| `timeline` | `items` (an array), `time` (key), `label` (key), `label_format` and `label_words` (optional, as in Formats), `detail` (key, optional), `time_format` (default `ago`), `limit` (1-20), `empty` | a dated list, newest first |
| `people` | `items` (an array), `name` (key), `status` (key, optional), `time` (key, optional), `empty` | a list of names with an initial badge and a status line (alert contacts and whether they acknowledged; faces seen by a people watch) |
| `devices` | `items` (an array), `name`, `kind`, `availability` (keys; `online` / `offline` / `not_checked` / other), `checked_at` (key), `empty` | a list of devices with a status dot and plain words ("Verified online", "Not checked") |
| `draft` | `id`, `label`, `value` (prefill), `max` (1-4096, default 2000) | a text box the owner can edit; buttons read it with `{"$draft": "<id>"}` |
| `buttons` | `items` (1-4, below) | a row of buttons; the first with `style: "primary"` spans the width |

On iOS and macOS, a local `timeline` can read a declared table source. Use
`{"$source":"notes.items"}` for a source named `notes`, `time:"at"` for the saved
row timestamp, and a column name for `label`. Optional `label_words` maps saved
values to display text. `detail` names a second column. `time_format` accepts
`ago` or `time`. The card reads up to the smaller of the source limit and the
timeline limit (default 10, maximum 20). Watch and service sources require
host support for those services.

`gallery` and `video` refs: a kept photo (from a `photos` source), a video from a button reply (for example
`POST /v1/camera/video` with `into`), or a gallery item the applet's `gallery` permission covers (a video needs `gallery_video`). The phone
draws them from its own storage; nothing is sent to a page.

### Card states (automatic)

Every pieces card has a state strip under the header that the phone sets, so agents never write it:

| State | When | Default words (override with `states.<state>`) |
|---|---|---|
| `loading` | a source is being read for the first time | "Reading from the phone…" |
| `empty` | every source is empty (no checks yet, no rows, no runs) | "Nothing yet." |
| `ready` | data is there and fresh | (no strip) |
| `stale` | the newest data is older than `fresh_s` | "Last update 2 h ago" |
| `paused` | the applet is paused | "Paused. Counts are kept." |
| `error` | a source read failed, or the watch's last check failed | that error's own message, in plain words |

`"states": {"empty": "No visible activity yet. Gaps and absence are unknown."}` changes the words. The
`status` piece is for anything else the agent wants to say.

### Buttons

```json
{"label": "Pause", "style": "plain", "do": {"pause_applet": true}}
{"label": "Run check now", "style": "primary", "do": {"run_workflow": true}}
{"label": "Refresh", "do": {"refresh": true}}
{"label": "Record 10 seconds", "style": "primary", "into": "clip",
 "do": {"method": "POST", "path": "/v1/mic/record", "body": {"duration_seconds": 10, "transcribe": true, "return_audio": false}}}
{"label": "Save note", "confirm": "Save this note on the phone?",
 "do": {"record": "notes", "row": {"text": {"$draft": "note"}, "source_at": {"$source": "clip.recorded_at"}}}}
```

Each button has `label` (1-24 characters), optional `style` (`primary` | `plain` | `danger`), optional
`confirm` (a question; the phone asks it in its own dialog before running), optional `into` (a name: the
reply becomes a `reply` source, so pieces can show it) and optional `only_if`. `do` is exactly one of:

| `do` | Does |
|---|---|
| `{"refresh": true}` | reads every source again |
| `{"pause_applet": true}` | pauses or resumes the whole applet (the button's label flips to Resume), the same as Pause in Installed applets |
| `{"run_workflow": true}` | runs the applet's workflow, if its trigger is `button` |
| `{"record": "<table>", "row": {…}}` | appends a row to an on-phone table (below); row values may be fixed values, `$source`, `$draft` or `$input` |
| `{"method", "path", "query", "body"}` | one API call, exactly what `Bridgit.act` sends today, run as the applet with its grants. `path` may be an array of parts where a `$watch` or `$input` reference fills one whole path segment, for example `["/v1/watches/", {"$watch": "main"}, "/pause"]`; the value must be a plain id (letters, digits, `-`, `_`), or the button is refused |

While a button runs it shows a spinner and the card blocks other buttons. Its result shows as a short
line under the buttons ("Saved", or the error in plain words). Every call is logged and sent to the agent
as `action.executed`, as `Bridgit.act` calls are today. Phase 3 adds `{"flow": "<id>"}`.

Permissions are derived from buttons as from any other part: an `{"method", "path"}` button adds that
endpoint's capability, a `record` button adds nothing (the table is the applet's own).

### What the owner sees on the install review

The review screen lists the card in words built from the pieces: "It shows a card with: today's observed
minutes and readings, recent episodes, and Pause and Remove buttons." Buttons that call endpoints are
named by what they do ("records 10 seconds of sound when you tap").

## The on-phone table

### Declaring a table

A package declares its tables in `processing.tables` (0-3 tables):

```json
"tables": [{
  "id": "receipts",
  "label": "Receipts",
  "columns": {
    "text": {"type": "text", "label": "Receipt text"},
    "total": {"type": "number", "label": "Total"},
    "currency": {"type": "choice", "options": ["EUR", "USD", "GBP"]},
    "photo": {"type": "photo"}
  },
  "keep_days": 365,
  "max_rows": 2000,
  "share_with_installer": false
}]
```

- Column types: `text` (at most 1024 characters), `number`, `integer`, `boolean`, `time` (ISO time),
  `date` (YYYY-MM-DD), `choice` (one of 2-32 `options`), `photo` (a kept photo ref). 1-16 columns; a
  column id is lowercase, like a step id.
- Every row also gets `id`, `at` (when it was written) and `by` (`flow` with the run id, `card`, or
  `agent`). Any column may be empty (`null`).
- `keep_days`: 1-3650, default 90. Rows older than that are deleted every day.
- `max_rows`: 1-10000, default 1000. When full, the oldest row is deleted to make room.
- `share_with_installer`: whether the agent that installed the applet may read rows (below). Default
  `false`. When `true` the review says so: "Your agent can read the Receipts rows."

### Writing a row

From a flow, with the new phase 1 step `record`:

```json
{"id": "save", "type": "record", "table": "meals",
 "row": {"activity": {"$step": "look.answers.activity"}, "photo": {"$step": "shot.photo"}}}
```

- Fields: `table` (a table this package declares), `row` (column → value; fixed values and `$step` /
  `$trigger` references). Result: `row_id`. Scope: none (the table is the applet's own).
- Validation refuses unknown tables or columns. At run time a value that doesn't fit its column (text too
  long, a number that isn't one, a choice not in `options`) fails the step, and `on_error` decides.
- A `photo` column needs the photo to be kept: phase 2 adds `"keep": true` to phase 1's `photo` step. A
  kept photo stays on the phone in the applet's own folder until its row or the applet is removed (or for
  `keep_days` of its table; a kept photo no row uses is deleted after 7 days).

From a card, with a `record` button (above).

The installing agent may also write rows with `POST /v1/applets/installed/{id}/tables/{table}/rows`
(`{"row": {…}}`) when the table is shared with it, so an agent can add rows it worked out itself.

### Limits

| Limit | Value |
|---|---|
| Tables per applet | 3 |
| Columns per table | 16 |
| Rows per table | 10,000 (`max_rows`) |
| One row | 4 KB of values (photos count as their ref only) |
| All rows of one applet | 5 MB |
| Kept photos of one applet | 1000 photos and 500 MB (wave 2); when over, the oldest kept photo no row uses goes first, then a `record` with a new photo fails with `storage_full` |
| Writes | 60 rows a minute per applet (a flow loop or a stuck button can't fill the phone) |

Rows are stored in the app's private storage, never in the gallery, and never leave the phone except
through an agent read the owner allowed.

### What the owner sees and deletes

- **Applets › Installed applets › (applet) › Data** lists each table: its label, how many rows, how much
  space, and how long rows are kept.
- Tapping a table shows its rows, newest first; tapping a row shows every column (photos full size).
- Each row can be deleted. "Delete all rows" empties a table (with a confirm). Deleting a row also deletes
  the kept photos only it used.
- Remove (the whole applet) deletes its tables and kept photos. `left_behind` lists `tables` if anything
  could not be deleted.
- Pause keeps every row.

### Updates

A new package revision may add tables and columns (old rows get `null`). Removing a table or a column, or
changing a column's type, deletes data, so the update waits for the owner, and the update screen says
what goes: "This update deletes the column Total from 120 rows." `keep_days` and `max_rows` may change
without asking; a lower value trims rows at the next daily clean-up.

### How things read it

| Reader | How |
|---|---|
| The card | a `table` source; the `table` piece draws it, `metrics` can show `{"$source": "receipts.count"}` |
| The flow | phase 1 `only_if` can test `{"step": "save.row_id", "exists": true}`; reading old rows inside a flow is not in phase 2 |
| The installing agent (if shared) | `GET /v1/applets/installed/{id}/tables/{table}/rows?limit=50&since=<row id>` returns `items[]` (oldest first after `since`) and `next`; and the event `applet.row_added` (`instance_id`, `table`, `row_id`) in `/v1/events`. Without `share_with_installer` both are refused with `not_shared` |
| Other agents | never |

### What it replaces

The receipt scanner and voice notebook send the owner's confirmed text to the agent with `Bridgit.respond`
today, and say "Controller processing has not been confirmed": the agent has to store it. With a table,
the text is saved on the phone the moment the owner taps Save, the owner can find and delete it later, and
the agent needs no server. An agent that does want the data reads it with the shared-rows call.

## Less boilerplate

The template registry requires `observation_schema`, `metrics`, `lifecycle`, `migration` and
`data_policy`. The phone ignores them, and every recipe carries the same copy (except `data_policy`, whose
copied text is sometimes wrong: the Pet monitor's copy says `remote_models: false` though its watch asks
Clef).

Phase 2:

- **The phone accepts packages without them.** It already doesn't read them; the builder guide
  (`site-content/content/builder/applet-packages.md`) stops telling agents to copy them.
- **`POST /v1/applets/validate` returns `package`**: the complete file, with those five sections filled
  in when missing, `permissions.required` filled with the derived permissions when missing, and every
  asset's `sha256` computed. That is exactly what to publish to the registry. Sections the agent did write
  are kept as written (but a `data_policy` that contradicts the parts is a validation warning).
- **Filled values** are the ones in today's recipes, with `data_policy` derived from the parts:
  `remote_models` is `true` when a watch uses `jev` or `clef` or a flow has `ask_model`; `retention.local`
  names each table and its `keep_days`, and kept photos; `execution` lists what leaves the phone (paid
  model questions, weather, alerts).

### What the backend would need (private `sponicgarden/bridgit-cloud`)

The registry's check lives in `feedback/src/template-schema.mjs` in the private backend repo, not here.
For phase 2 it needs:

1. Accept `ui.card.pieces` / `ui.card.sources` / `ui.card.fresh_s` / `ui.card.states` (and a card with no
   `asset`), `processing.tables`, and the `record` step inside `processing.workflow`.
2. For adapter `android.package.v1`, fill the five sections itself when they are missing, with the same
   values the phone fills, so publishing works whether or not the agent ran validate first. The shared
   test: a recipe's `applet.json` with those sections removed, filled by the phone and by the backend,
   must come out the same.
3. Then regenerate this repo's public copies (`node tools/public-snapshot.mjs write <this checkout>` in the
   backend repo: `website/template-values.mjs`, `website/content/applets/library.json`) and commit them
   here. Backend code is not copied into this repo.

## The seven recipes, rewritten

Every recipe drops its 14 KB `card.html`, its `ui.card.data` block and the five copied sections. Typical
size goes from 17-21 KB to 2-5 KB.

| Recipe | Today (card mode) | With pieces |
|---|---|---|
| Pet monitor | `watch` + `/tally` | full example below |
| Situation counter | `watch` + `/tally` + `count_heading` | tally source; `metrics` "Times seen today" (`{"$source": "count.today.labels.<label>.episodes"}`) and "Readings"; `timeline` of episodes; Pause button |
| Room change watcher | `watch` (status) | status source; `metrics` "Checks" and "Change matches"; `timeline` of `recent_checks` (`time: "at"`, `label: "matched"` with `label_words` "Image changed" / "No change"); `note` "Image change is not person or danger detection"; Pause button |
| Daily briefing panel | `weather` | call source `GET /v1/weather` (`every_s: 900`); `metrics` temperature (`celsius`), wind, low/high, rain; `note` with the attribution; Refresh button. The schedule's reminder is unchanged |
| External device dashboard | `lan` | call source `GET /v1/lan/devices`; `devices` piece; `note` "Listing does not probe devices"; Refresh button |
| Receipt scanner | `ocr` | button "Read selected receipt" (`POST /v1/ocr` with `gallery_id` from `$input`, `into: "scan"`); `draft` prefilled with `{"$source": "scan.text"}`; button "Save receipt" → `record` into `receipts`; `table` piece of saved receipts with `owner_delete` |
| Voice notebook | `voice` | button "Record 10 seconds" (`POST /v1/mic/record`, `into: "clip"`); `draft` prefilled with the transcript; "Save note" → `record` into `notes`; `timeline` of saved notes |

### Full example: Pet monitor

The watch is unchanged from today's recipe (shortened here). Everything else in the file is shown.

```json
{
  "format": "bridgit-template/1", "id": "pet-monitor", "version": "2.0.0", "kind": "applet",
  "name": "Pet activity monitor",
  "summary": "A photo-based activity tally with explicit gaps, plus an offline card.",
  "runtime": {"adapter": "android.package.v1", "applet_key": "pet-monitor", "supports_dynamic_execution": false},
  "config_schema": {"type": "object", "additionalProperties": false,
    "required": ["camera", "interval_s", "max_paid_per_hour"],
    "properties": {
      "camera": {"type": "string", "enum": ["rear", "front"]},
      "interval_s": {"type": "integer", "minimum": 30, "maximum": 3600},
      "max_paid_per_hour": {"type": "integer", "minimum": 1, "maximum": 60}}},
  "defaults": {"camera": "rear", "interval_s": 30, "max_paid_per_hour": 10},
  "processing": {
    "watches": [{"id": "main", "request": {
      "label": "Pet activity samples", "data": ["camera"], "camera": {"$input": "camera"},
      "questions": {"pet": {"type": "noul", "instructions": "Is an animal visible in this photo?"},
                    "activity": {"type": "choice", "instructions": "Classify only the visible animal…",
                                 "criteria": {"resting": "…", "eating": "…", "drinking": "…", "other": "…", "unclear": "…"}}},
      "model": "clef", "interval_s": {"$input": "interval_s"}, "max_paid_per_hour": {"$input": "max_paid_per_hour"},
      "local": {"change_check": true, "sensitivity": "high", "learn_noise": true, "max_reuse_s": 900},
      "tally": {"track": "activity", "labels": ["resting", "eating", "drinking", "other"],
                "min_confidence": 0.8, "gap_s": 90, "keep_days": 30, "seen": {"answer": "pet", "min": 0.6}},
      "rules": [{"id": "no-meal-by-6pm", "when": {"fewer_than": 1, "of": "eating", "by": "18:00"},
                 "do": {"method": "POST", "path": "/v1/interactions",
                        "body": {"kind": "notice", "title": "No meal seen yet", "text": "{message}"}}}]}}]
  },
  "permissions": {"required": ["camera", "interactions", "watches"], "optional": [], "remote": [], "automatic_grants": false},
  "ui": {
    "inputs": {
      "camera": {"label": "Camera", "help": "The phone camera that faces the pet's spot."},
      "interval_s": {"label": "Seconds between photos", "help": "30 to 3600. Longer means fewer paid checks."},
      "max_paid_per_hour": {"label": "Paid photo checks an hour, at most", "help": "Unchanged pictures reuse the last answer for free."}},
    "card": {
      "title": "Pet activity monitor",
      "sources": {"activity": {"watch": {"$watch": "main"}, "read": "tally"}},
      "fresh_s": 120,
      "states": {"empty": "No visible activity samples yet. Gaps and absence are unknown."},
      "pieces": [
        {"type": "header", "eyebrow": "Bridgit applet", "text": "A little window into your pet's day."},
        {"type": "metrics", "items": [
          {"label": "Observed minutes", "value": {"$source": "activity.today.watched_minutes"}, "format": "minutes"},
          {"label": "Readings", "value": {"$source": "activity.today.checks"}, "format": "number"}]},
        {"type": "table", "rows": {"$source": "activity.today.labels"},
         "columns": [{"key": "$key", "label": "Activity"},
                     {"key": "episodes", "label": "Episodes", "format": "number"},
                     {"key": "minutes", "label": "Minutes", "format": "number"}],
         "empty": "Nothing counted yet today."},
        {"type": "timeline", "items": {"$source": "activity.episodes"}, "time": "start", "label": "label",
         "detail": "minutes", "limit": 5, "empty": "No episodes yet. Missing coverage is unknown."},
        {"type": "note", "text": "Sampled observations, not continuous coverage. Gaps and absence are unknown."},
        {"type": "buttons", "items": [
          {"label": "Refresh", "style": "primary", "do": {"refresh": true}},
          {"label": "Pause", "do": {"pause_applet": true}}]}
      ]
    }
  }
}
```

About 3.5 KB instead of 20.5 KB. `observation_schema`, `metrics`, `lifecycle`, `migration` and
`data_policy` come back filled from `POST /v1/applets/validate` for publishing.

Today's card also has a Stop button that deletes the watch. On an installed applet that leaves the applet
half-running, so the rewrite drops it: Remove in Installed applets removes everything.

## Test plan

Unit tests (pure Kotlin, like `CardRules` and `CardActions`):

- Card validation: `pieces` xor `asset`; every piece type with its fields and bounds; unknown piece types
  and fields refused; `sources` names, kinds and limits; `$source` / `$draft` paths resolve to a declared
  source or draft; `$watch` in sources and button paths; path-segment references refuse non-id values;
  16 KB limit; text parts and the 1024-character cap.
- Call sources: only `GET`; the endpoint must exist and be card-callable (same matcher as `Bridgit.act`);
  derived permissions include every call and button endpoint; `every_s` bounds.
- Formats: each `format` on good, missing and wrong-typed values (`null` → `empty`).
- Card state: empty / ready / stale (`fresh_s`) / paused / error chosen correctly from source data.
- Tables: declaration bounds; `record` step validation (unknown table or column refused); run-time type
  checks per column type; `max_rows` drops oldest; `keep_days` clean-up; the 4 KB row, 5 MB applet and
  60-a-minute limits; kept-photo accounting and `storage_full`.
- Updates: added column keeps rows; removed or retyped column waits for the owner with the right words;
  table rows survive an update that changes only the card.
- Validate filling: each of the seven recipes with the five sections removed validates, and the filled
  `package` equals today's sections except the derived `data_policy` fields; a written section is kept.
- Agent access: shared-rows read and write, `since` paging, `applet.row_added`, `not_shared` when not
  shared, refused for any other agent.
- Old packages: every current recipe `applet.json`, with its HTML card, still installs and behaves as
  before (existing applet tests pass unchanged).

On the A11, with a `cc.bridgit.app.test_claude_cards` build:

- Install each of the seven rewritten recipes; each card draws, in light and dark mode and at the largest
  text size, with TalkBack reading every piece.
- Pet monitor: counts and the timeline update while the card is open; the card goes stale when the watch
  is paused, and shows Paused.
- Voice notebook: record, edit the draft, save; the row appears in the card and in Installed applets ›
  Data; delete it there and it disappears from the card.
- Receipt scanner with a kept photo: the photo shows in the row; deleting the row deletes the photo.
- Remove an applet with rows: Data is gone and `left_behind` is empty.
- A flow with `photo` (`keep: true`) → `ask_model` → `record`, and a card with `gallery` and `table`
  pieces over it.

Website: `builder-recipes.mjs` builds the seven recipes from pieces, the look-alike preview renders each
one, and the site's tests check every `applet.json` passes the phone's validator fixtures.

## Not in phase 2

- Mixing pieces and custom HTML in one card (an `html` piece).
- Reading old table rows inside a flow (for example "if no meal row today"), sums or charts over a table.
- Exporting a table (CSV or share sheet), or sharing rows with anyone other than the installing agent.
- Per-row buttons in `table` and `devices` pieces (for example "turn this lamp on").
- Buttons that run a named flow (`{"flow": "<id>"}`) and watch rules or schedules that run a flow: phase 3.
- Charts (bar, line), maps and live camera views as pieces.
- Owner-chosen layout or themes; pieces always use Bridgit's style.
- Phone-to-phone or cloud sync of tables.

## Capture into an installed applet’s table

The Android, iOS and macOS hosts accept a camera button that names a declared
table and photo column. The row object supplies fixed values for other columns.
This example requests the rear camera and a JPEG with a maximum edge of 2048
pixels. Use `medium` for 1280 pixels. Include `camera` and `interactions` in
the package's required permissions. A host can still require camera consent.

```json
{"id":"camera","label":"Take photos","do":{"camera":{"table":"photos","photo":"photo","row":{"status":"new"},"size":"large","lens":"back"}}}
```

On Apple devices, accepting a photo saves the image and row together. A
`taken_at` column of type `time` receives the acceptance timestamp. The
Insurance Inventory package shows the complete table and gallery declarations.
Its gallery reads from the installed instance's `photos` table, translates
`status` into a caption, and displays the item count when present. Selecting
a thumbnail opens the saved photo.
