# Applet flows: one simple way to orchestrate an applet

Status: phase 1 spec (5 Nov 2026). Phase 2 and 3 are outlined at the end and get their own specs.

## Why

An agent building an applet should spend its thinking on *which* capabilities to use and *how they connect*,
not on layout and not on stitching together four different mini-languages. Today an applet's behaviour is
split across:

| Part | Can | Can't |
|---|---|---|
| Watch (`POST /v1/watches`) | sense, filter on the phone, ask Jev/Clef, count, fire rules | a rule fires exactly one raw API call, and only on counts |
| Schedule (`POST /v1/schedule`) | run calls at set times | spells its calls differently (`call: "POST /v1/…"`) from watch rules (`method` + `path`) |
| Workflow (`workflow.propose`) | button / interval / charging / geofence / applet-event trigger | steps only notify, speak, ring, alert or signal; no photo, no model, no condition, no data between steps |
| Card (`Bridgit.act`) | call anything | logic lives ad hoc inside each card's script |

So "when motion is seen → take a photo → ask Clef if the dog is eating → if not, ask the owner → if they
say yes, alert the family" cannot be written as one thing on the phone. Agents fall back to their own
server, whose timers stop when it stops.

## What we borrow (and what we don't)

Evaluated: Zapier, Make, n8n, IFTTT, Power Automate, Pipedream, Activepieces, plus Home Assistant (the
closest analogue: device-centred, trigger/condition/action, typed blueprint inputs like our `$input` blanks).

| Borrow | From |
|---|---|
| A flow reads as one plain sentence the owner understands | IFTTT |
| A fixed menu of named, typed steps; the agent picks, never invents | Zapier, Activepieces |
| Trigger → steps, linear; a step can be skipped by a condition (a "filter") | Home Assistant, Zapier |
| Named step results that later steps use | n8n |
| Per-step error policy (stop / skip / retry) | Make |
| "Ask a person and wait" as a first-class step | Power Automate approvals |
| A log for every run, step by step | n8n executions |

Not borrowed: visual canvas, loops/iterators, routers and nested branches, code steps, thousands of
third-party connectors. Flows stay declarative and bounded; `supports_dynamic_execution` stays false.

## Phase 1: flow steps in the workflow engine

Phase 1 upgrades the existing on-phone workflow (`platform/WorkflowEngine.kt`, `workflow.validate` /
`workflow.propose` / `workflow.run`, and `processing.workflow` in applet packages) into the flow described
here. Every existing workflow stays valid and behaves as before.

### Shape

```json
{
  "name": "Dinner check",
  "trigger": {"type": "watch", "watch": "<watch id>", "on": "match"},
  "steps": [
    {"id": "shot", "type": "photo", "camera": "rear"},
    {"id": "look", "type": "ask_model", "model": "clef", "photo": {"$step": "shot.photo"},
     "questions": {"eating": {"type": "noul", "instructions": "Is a dog eating from a bowl?"}}},
    {"id": "check", "type": "ask_owner", "only_if": {"step": "look.answers.eating", "below": 0.5},
     "title": "No dinner seen", "text": "Your dog hasn't been seen eating. Alert the family?",
     "choices": ["Alert them", "It's fine"], "wait_s": 600},
    {"type": "alert", "only_if": {"step": "check.choice", "is": "Alert them"},
     "text": ["Dinner check: ", {"$step": "look.answers.eating"}], "destinations": ["<destination id>"],
     "on_error": "retry", "retries": 2}
  ]
}
```

### Triggers

Existing, unchanged: `button`, `interval`, `charging`, `geofence`, `applet.event` (`application.event`).

New:

- `{"type":"watch","watch":"<watch id>","on":"match"}`: runs when that watch matches (its conditions are
  met and its callback is due). `"on":"rule","rule":"<rule id>"` runs when that tally rule fires instead.
  The watch must belong to the same agent. In an applet package write `"watch": {"$watch": "main"}`; the
  installer creates the watches first and fills in the real id. The trigger's data is available to steps as
  `{"$trigger": "message"}` (a rule's message), `{"$trigger": "answers.<question>"}` (a match's answers) and
  `{"$trigger": "at"}`. No extra scope: the watch is already the agent's own.

### Step menu

Every step may have:

- `id`: lowercase name, needed if a later step uses its result. Unique in the flow.
- `only_if`: `{"step": "<id>.<path>" | "trigger": "<path>", <test>}`. The test is exactly one of
  `"is": value`, `"is_not": value`, `"in": [values]`, `"at_least": n`, `"below": n`, `"exists": true|false`.
  A step whose condition is false is recorded as `skipped` and gives no result. A condition on a step that
  was skipped or failed is false (except `"exists": false`, which is true).
- `on_error`: `"stop"` (default: end the run as failed), `"skip"` (record it and carry on), or `"retry"` with
  `"retries": 1-3` (then stop). Retries wait 2 s, 5 s, 10 s.

| Step | Fields | Result | Scope |
|---|---|---|---|
| `photo` | `camera`: `rear`, `front` or a local camera id (`lan:…`) | `photo` (a reference usable by `ask_model`), `taken_at`, `camera` | `camera.snapshot` |
| `ask_model` | `model`: `jev`, `clef`, or `glm`; `questions` (the watch questions format); optional `photo`: `{"$step":"<id>.photo"}` | `answers` (one value per question), `model`, `cost_usd` | `decisions` |
| `ask_owner` | `title`, `text`, `choices` (2-6), `wait_s` (30-3600, default 300) | `choice`, or `timed_out: true` | `interactions` |
| `wait` | `seconds` (1-300) | none | none |
| `stop` | none (use `only_if`) | ends the run as completed | none |
| `notice` | `title`, `text` | `interaction_id` | `interactions` |
| `speak` | `text` | none | `audio.speak` |
| `ring` | `seconds` (1-30) | none | `phone.control` |
| `alert` | `text`, `destinations` (1-3) | `alert_id` | `alerts` |
| `event` | `text` | none | none |

`ask_model` is a paid remote call through the Bridgit team backend (Outbound shows it like a watch's model
call). A flow has a hard cap of 4 `ask_model` steps per run, and a flow-level optional
`"max_paid_per_day": 1-500` (default 50) after which `ask_model` steps fail with `paid_cap` (so `on_error`
decides what happens).

### Using results

- `{"$step": "<id>.<path>"}` and `{"$trigger": "<path>"}` are whole-value references, the same rule as
  `$input` and `$watch`: the node is replaced by the value, never spliced into a request, URL or HTML.
- Plain-text fields (`notice.title`, `notice.text`, `speak.text`, `alert.text`, `ask_owner.title`,
  `ask_owner.text`) also accept an array of parts: strings and references, joined into one string (values
  become text, at most 4096 characters in total). These fields are shown as plain text, never as HTML.
- A reference to a step that comes later, or to an unknown id, is a validation error. A reference to a step
  that was skipped or failed gives `null` (shown as an empty string in text).

### Runs and the run log

Before proposing a workflow, use `workflow.simulate` through `POST /v2/call` or
`bridgit_workflow_simulate` over MCP. It validates an inline flow and uses fixtures for
device and service results. Inspect `steps` and `would` to see which actions each case
reaches. The [control guide](https://bridgit.cc/learn/control.md) includes a runnable
example and supported steps. Whole-package simulation is a separate design in
[B2](applet-dev-experience.md#b2-simulate-a-flow-without-paying).

- Each run is an `execution` record (kind `execution`, as today), now with `trigger` (type and data, without
  photos), `steps` (one entry per step: `id`, `type`, `status` = `ok` | `skipped` | `failed` | `unknown_outcome` | `not_run`,
  `ms`, `error`, a short `result` without photos), `status` = `completed` | `failed` | `unknown_outcome`,
  `started_at`, `finished_at`, `cost_usd`.
- New read tool `workflow.runs` `{id, limit?}`: that workflow's newest runs (default 10, max 50).
- Events: `workflow.completed` (as today) and new `workflow.failed`.
- A step that fails with `on_error: stop` ends that run as `failed`. The workflow stays `active`: the next
  trigger can run it again. A restart during execution marks that run `unknown_outcome`.
  If an effect may already have happened, the run stops and reports the uncertainty.
  Check the destination before repeating it. Loss of authority can block the workflow.
- A skipped conditional step includes its `condition` and a readable `reason`. Photo
  entries identify the selected `camera` even on failure. Send and alert results can
  reference a delivery or alert record whose status changes after the flow completes.
- Run time limit: 120 s plus the `wait_s` of each `ask_owner` step and the `seconds` of each `wait` step.
- Watch-triggered and timed runs that arrive while the same flow is running are dropped and counted
  (`dropped_runs` on the workflow) rather than queued.

### Plain-sentence summary

`workflow.validate` also returns `summary`: the flow as one plain sentence, for example "When Pet watch
matches: take a photo with the rear camera, ask Clef "Is a dog eating from a bowl?", if the answer is no ask
you "No dinner seen" (waits up to 10 minutes), if you choose "Alert them" alert 1 contact." The owner's
approval screen (Device tools) and the applet install review show this sentence.

### Limits and validation (unchanged where not listed)

- 1-32 steps, 64 KiB, no scripts, URLs or app control.
- Required scopes are derived from the trigger and the steps (as today); `camera.snapshot` and `decisions`
  join the derived set when used. `decisions` is a new Device tools switch, "Jev and Clef questions", off by
  default like the other workflow features, because each question is a paid remote call.
- At the start of a run only the grants are checked; each step checks that its own feature is ready when it
  runs (so a camera that isn't ready fails or skips the photo step by its `on_error`, instead of stopping
  every run before it starts).
- Unknown fields are rejected, as today.

### Not in phase 1

- Watch rules and schedules keep their own `do`. (Phase 3 lets them point at a flow instead.)
- Recording rows into a table, and card pieces (phase 2).
- Waiting on the owner across a phone restart (an interrupted `ask_owner` run is `unknown_outcome`).

### Tests

- Validation: every new step and trigger, `only_if` tests, reference rules (forward / unknown refs refused),
  text parts, retries bounds, derived scopes, summary sentence.
- Running: results flow between steps; `only_if` skips; `on_error` stop / skip / retry; failed run leaves the
  workflow active; authority loss blocks it; `ask_owner` answered and timed out; `workflow.runs` log.
- Old workflows: the existing `WorkflowContractTest` still passes unchanged.
- On the A11: a test build runs a button flow with photo → ask_model → ask_owner → notice end to end, and a
  watch-triggered flow.

## Phase 2 (outline, separate spec): card pieces and tables

- Built-in card pieces the phone draws in Bridgit's style: metrics, photo gallery, video, table, timeline,
  people, devices, buttons. The card lists pieces and their data sources; agents write no CSS. Custom HTML
  stays as an escape hatch.
- An on-phone table primitive: a flow step `record` appends a row; a card `table` piece shows it.
- Validate fills in the package sections the phone ignores, so agents stop copying them.

## Phase 3 (outline): one vocabulary everywhere

- Watch rules, schedules and card buttons can run a flow (`"do": {"flow": "<id>"}`), so the step menu is the
  one action vocabulary.
- The builder guide becomes a picker: trigger → sense/decide steps → actions → card pieces.
