#!/usr/bin/env python3
"""Pack local applet assets into JSON or generate revision descriptors for detached JPEGs."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys


def check_jpeg(data, name):
    if not data.startswith(b"\xff\xd8\xff") or not data.endswith(b"\xff\xd9"):
        raise ValueError(f"{name}: expected a JPEG")
    offset = 2
    while offset + 9 < len(data) and data[offset] == 255:
        marker = data[offset + 1]
        if marker == 255:
            offset += 1
            continue
        if marker in (0xD9, 0xDA):
            break
        length = int.from_bytes(data[offset + 2:offset + 4], "big")
        if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
            height, width = struct.unpack_from(">HH", data, offset + 5)
            if 1 <= width <= 4096 and 1 <= height <= 4096:
                return
            raise ValueError(f"{name}: JPEG dimensions must be 1 to 4096 pixels per edge")
        if length < 2:
            break
        offset += 2 + length
    raise ValueError(f"{name}: missing JPEG frame header")


def pack(manifest):
    directory = manifest.resolve(strict=True).parent
    with manifest.open("rb") as stream:
        raw = stream.read(131073)
    if len(raw) > 131072:
        raise ValueError("source exceeds 128 KiB")
    definition = json.loads(raw)
    if not isinstance(definition, dict) or definition.get("format") != "bridgit-template/1":
        raise ValueError("expected a bridgit-template/1 object")
    assets = definition.get("assets", {})
    if not isinstance(assets, dict) or len(assets) > 16:
        raise ValueError("expected at most 16 named assets")
    for name, asset in assets.items():
        if not isinstance(asset, dict):
            raise ValueError(f"{name}: expected an asset descriptor")
        if "path" not in asset:
            continue
        detached = asset.get("storage") == "revision"
        fields = {"path", "media_type", "storage"} if detached else {"path", "media_type"}
        if set(asset) != fields or not isinstance(asset["path"], str):
            raise ValueError(f"{name}: provide path and media_type for a local file")
        relative = Path(asset["path"])
        file = (directory / relative).resolve(strict=True)
        if relative.is_absolute() or not file.is_relative_to(directory) or not file.is_file():
            raise ValueError(f"{name}: expected a regular file inside the manifest directory")
        limit = 4 * 1024 * 1024 if detached else 49152
        with file.open("rb") as stream:
            data = stream.read(limit + 1)
        if len(data) > limit:
            raise ValueError(f"{name}: asset exceeds {limit} bytes")
        if detached:
            if asset["media_type"] != "image/jpeg":
                raise ValueError(f"{name}: detached media must be a JPEG")
            check_jpeg(data, name)
            asset["size"] = len(data)
        elif asset["media_type"] == "image/png":
            if len(data) < 33 or data[:16] != b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR":
                raise ValueError(f"{name}: expected a PNG with an IHDR header")
            if any(not 1 <= edge <= 1024 for edge in struct.unpack(">II", data[16:24])):
                raise ValueError(f"{name}: PNG dimensions must be 1–1024 pixels")
            asset.update(base64=base64.b64encode(data).decode("ascii"), size=len(data))
        elif asset["media_type"] in {"text/plain", "text/markdown", "text/html", "image/svg+xml", "application/json"}:
            asset["text"] = data.decode("utf-8")
        else:
            raise ValueError(f"{name}: unsupported media_type")
        del asset["path"]
        asset["sha256"] = hashlib.sha256(data).hexdigest()
    result = json.dumps(definition, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode() + b"\n"
    if len(result) > 131072:
        raise ValueError("packed definition exceeds 128 KiB")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    try:
        sys.stdout.buffer.write(pack(parser.parse_args().manifest))
    except (ValueError, OSError) as error:
        parser.exit(1, f"{error}\n")
