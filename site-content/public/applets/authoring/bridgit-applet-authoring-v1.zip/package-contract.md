# Portable applet package contract

Production registry status, 6 November 2026. All 13 maintained public applets use
portable packages. The Android release supports the portable monitor. The iOS
simulator and Mac Catalyst host installed all 13 from production and reopened
their pinned editions offline. The platform sections describe which operations
each host can execute. Apple distribution is tracked separately.

## Required result

An author, including an LLM, produces ordinary text files without a live device,
account, service call, or Bridgit API. A versioned offline validator checks them.
Importing a file and publishing a library release are separate operations. The same
package must execute through the supported capabilities on Android, iOS and macOS.
A remote portal is not evidence of local execution. All existing applets must be
converted before this release, and no applet definitions or package assets belong
in application bundles. Generic platform drivers remain compiled application code.

## Package and installation

The existing `bridgit-template/1` envelope remains the starting point. The portable
adapter is `bridgit.package.v1`; Android recognizes its legacy `android.package.v1`
alias for compatible installations and upgrades. The `android.dog.v1` adapter is
legacy native behavior to convert, not a portable runtime.

A package contains stable identity and version, display metadata, typed settings
and defaults, declared permissions, data tables and retention, flows and triggers,
UI, assets, and migration metadata. References are whole JSON values, never string
interpolation. Secrets and owner credentials are never package content. Inputs and
persistent records belong to an installed instance, not to the shared template.

A library entry is metadata plus a pointer to an immutable published revision.
Search and pagination fetch small records without downloading definitions. An
installation pins and persists its complete validated definition for offline use.
Fetching the catalog does not register instance data or enable a hosted backend.

## Offline authoring check

Extract `site-content/public/applets/authoring/bridgit-applet-authoring-v1.zip`.
Run `java -jar validate-applet.jar /absolute/path/to/applet.json` with Java 17
or newer. The archive contains the packer, package and service references,
endpoint inventory and example packages. The standalone validator checks a self-contained
JSON package through the Android package, default-input, watch, schedule and workflow
validators. It checks trigger fields, flow limits and conditions, resolves declarative
endpoint references using the checked-in API inventory, and reports missing declared
permissions. It makes no Bridgit API request, creates no instance and runs no flow.
Maintainers regenerate and exercise the distributable using
`python3 tools/build-applet-authoring-kit.py` with their cached Android build
toolchain. Users need only Java to run the downloaded validator.

The source-checkout alternative, `tools/validate-applet.sh applet.json`, also
prints this invocation’s JSON result on stdout and sends build logs to stderr.
An invalid package produces `valid: false`, the diagnostic, and a nonzero exit. A build
failure before validation produces no report on stdout. Supply a second argument for a
separate output directory when running independent authoring sessions. By default
the command exports `app/build/applet-authoring/validation.json`,
`flow-contract.json`, and `services.json`. The latter two enumerate the actual
compiled step fields/scopes, limits, service selections and example request shapes.
The validation result explicitly lists checks it does not perform. Successful
static validation cannot prove a live connection, grant or platform capability.

### Android kitchen workflow variants

To make a private variation of Chef’s Helper, fork its published revision and
retain its `processing.flows` and table definitions. The `chef.signed-edition-budget.v2` service reads
the instance’s own `ingredients` and `activity` tables. For the `observe` operation the
settings row selects the camera, controls muting and starts an observation
session. The step can set `session_s` and `tip_gap_s`. Their defaults are 3600 and 45 seconds. The owner must enable the fork’s own portal and approve its model and
device permissions. Enabling the original applet’s portal cannot enable a fork.
The registry assigns the fork a fresh package ID. Later revisions can rename it and must keep that ID. Apple hosts support foreground kitchen scans from saved photos, with explicit approval
for each hosted submission. On Apple, an owner can start a foreground cooking session for a single
Chef service step with the `observe` operation with an interval trigger. The owner chooses
a camera, optional goals and whether to speak suggestions. Each frame requires
review before submission. The service receives current pantry labels and notes
and the previous tip. The host stores observations in the instance’s `activity`
table and discards frames. Stop, leaving the applet, backgrounding the app or a
package-defined timeout ends the session. Android supports unattended sampling during
an authorized session. The portable package declares each flow
independently.

On Android, downloading a registry edition on a linked phone binds its paid kitchen
flows to that account. At runtime the host signs the account binding, package ID,
registry key, revision and installed flow ID. The backend checks the current
link and budget on each call. To enable an edition installed before linking, or
to move it to a different linked account, open the published edition again and
approve the update. That same-edition review preserves local tables and settings.
A personally modified registry installation must publish and review its updated
edition to run a paid library flow.

An Android tally watch keeps its ID, episodes, pause state and spending counters when an
edition changes only its watch label or sampling interval. Existing readings keep the
frame duration used when they were captured. Replacing a tally definition or removing
its watch requires owner review. The update lists the affected watch before removing
its counts and episodes.

### Pet activity checks

The `pet-monitor` recipe (3.1.2) runs its `review` flow when the owner taps
“Check pet activity.” It uses the configured camera, asks Clef the choice question
in `processing.flows`, and saves the answer in the instance's `checks` table.
The card shows the ten newest owner checks after restart. The history source is
`owner_checks.items`; the watch tally counts scheduled samples separately.
A fork can edit the question instructions or criteria offline. When adding a choice,
include it in the table column's allowed options. The flow has a ten-call daily cap
and uses the owner's applet budget. Its manual checks run on Android, iOS and macOS.
The scheduled tally and dinner rule currently need an Android watch host.
An iPhone owner can run a foreground photo check. For continuous monitoring
while that iPhone is locked, the architecture requires a separately authorized
monitoring device. iOS interrupts ordinary camera capture when the app enters
the background, and a background task request supplies only an earliest start
time. [Camera interruptions](https://developer.apple.com/documentation/avfoundation/avcapturesession/interruptionreason/videodevicenotavailableinbackground)
and [background scheduling](https://developer.apple.com/documentation/backgroundtasks/bgtaskrequest/earliestbegindate).
Historical `dog-monitor` revisions through revision 6 use the legacy Android tracker. Revision 5
(package 1.4.0) carries its model note and questions in `processing.classifier`.
Keep the four question IDs, types and choice labels from the example because
the tracker interprets those answers. Change the note, instructions and criteria
descriptions as needed. Each text field accepts 1–1,000 UTF-16 code units.
The host expands `{{photo}}` in question instructions to the selected service's
image reference. Only Jev receives the optional bounding-box question during
camera aiming. Changing the classifier requires owner review. One device runs
one legacy tracker. Use the portable `pet-monitor` package for independent
installations and histories. Older native editions download and cache the
immutable revision-6 classifier on their first approved model check. Revision 6
(package 1.5.0) adds `processing.classifier.sound`, a choice question with
`instructions` and six required criteria keyed by `barking`, `growling`,
`eating`, `drinking`, `other`, and `unclear`. Edit the descriptions or
instructions in a fork. A revision-5 fork retains its own visual questions and
uses the revision-6 sound question until its owner approves a sound edit.

### Fairytale history in a private fork

Fairytale 1.1.2 uses the Android host's `POST /v1/story/generate` (API revision
116) with the owner's reviewed frame and portrait capture IDs. The card writes
only the returned title, narration and mode to its own declared `stories` table
using `POST /v1/applet/tables/stories/rows`. Copying the card and table into a
private fork preserves history under the fork's instance. Older pinned editions
can continue using `POST /v1/story`. Apple hosts still need the capture, story
and presentation capabilities to run this card.

## Flows: required authoring reference

The complete reference must enumerate every accepted trigger and step with closed
fields, types, required values, defaults, numeric bounds, input/output schemas,
required capabilities and scopes, side effects, service usage, and platform support.
It must cover conditional execution, result references, called-flow arguments,
iteration bounds, cancellation, waiting for people, timeouts, retries, concurrency,
run/day cost caps, and errors. Every example must pass the offline validator and
runtime conformance corpus. Unknown types, properties, services and forward/dangling
references fail explicitly. Documentation cannot advertise planned steps as runnable.

The offline kit includes Draft 2020-12 authoring schemas for all 21 step input shapes and all trigger types. Apply these to inputs after filling package configuration. The build checks step field names against the runtime inventory. The Kotlin validator also enforces context-dependent conditions, earlier step IDs, table declarations, scope derivation and budget limits. The accompanying workflow guide describes effects, results and supported hosts.

The current Android source of the step vocabulary is `platform/FlowSteps.kt`,
conditions are `platform/FlowConditions.kt`, and execution is `platform/WorkflowEngine.kt`.
`docs/applet-flows.md` and `docs/applet-reach.md` describe existing behavior but are
not a substitute for the complete generated contract. The current menu includes
`photo`, `ask_model`, `ask_owner`, `wait`, `stop`, `notice`, `speak`, `hear`, `ring`,
`alert`, `event`, `record`, `service`, `appraise`, `kitchen`, `update`, `share`, `send`, `context`,
`set_mode`, and `lookup`. Specialized `kitchen` and native Pet behavior must be
expressed through portable definitions and generic capabilities before release.

## Services: required authoring reference

The contract must distinguish a service capability, a named service/provider/model,
and an owner-managed credential or connection binding. Explicit selection and any
selection policy must have defined semantics; missing bindings or unavailable
services produce a specified error. No silent model substitution, capability
escalation, cloud use, or paid fallback. Fallback order, if supported, must be
explicit and respect both applet and owner budgets and disclosure.

Current Android `ask_model` accepts `jev`, `clef`, and `glm`. The current service
reference is `judgment/ServiceCatalog.kt`; runtime `GET /v1/services` discovers live
availability but is not required to author text. A service snapshot in the authoring
kit must include schemas, media support, typed outputs, errors, privacy behavior,
limits, and platform prerequisites. Account secrets remain write-only outside the
package. Offline validation never calls a provider or spends money.

## Assets and publication

Packages can contain bounded text or verified asset references. Referenced assets
need a media type, byte size, SHA-256 and a controlled delivery location. Importers
must verify all bytes before activation and support a complete offline archive.
A URL or content hash conveys no authorization. Do not fetch arbitrary URLs using
owner credentials; private assets require authorization to the enclosing revision.
User photos, recordings, and history are never reusable package assets.

The registry stores new text and PNG assets as exact bytes in an owner-scoped,
content-addressed private R2 bucket and reconstructs self-contained JSON on an
authorized read. Legacy inline releases remain readable. Authors can reference
local files in the source manifest and run `tools/pack-applet.py` offline.
Android and Apple verify the SHA-256 of the PNG bytes. Within one registry owner,
revisions and forks can reuse the same verified object. A revision and its asset
references commit together. Published and deprecated pins retain their assets.
Deleting the last referencing draft makes its objects eligible for collection
after the upload reservation expires (24 hours). A half-hourly job retires
unreferenced objects in bounded batches and checks the bucket for interrupted
uploads. A concurrent upload gets a new physical key if collection has already
retired the previous one. The registry also accepts detached JPEGs up to 4 MiB and 4096 pixels per edge.
An authenticated editor stages each file by digest before attaching its small
descriptor to a revision. The registry copies authorized media into a fork
owner’s storage. See the library management guide for the upload and download
contract. The Apple host downloads media after review and commits verified files with the installed revision in its account-scoped SQLite library. A failed update preserves the prior files. Android verifies each file before changing the running installation, stores it privately per instance, and prunes files no longer named by the approved manifest. Existing verified files can be reused offline for that instance. A missing file requires a signed read of its exact registry revision.

Android stores each installed definition, pinned source, settings and private development journal together in its local SQLite database. An upgrade from the preferences-based library imports existing records transactionally and retains their instance IDs and revisions. Indexed lookups resolve an applet agent, package or budget without decoding other installations. The existing instance-management APIs use the same store.

Publication is explicit: private, public, or unlisted. Unlisting removes discovery
while exact links and cached installations remain usable. Making an entry private
restricts subsequent server reads; it cannot erase already downloaded files.
The fork operation assigns a fresh `definition.id` and records the exact parent
key and revision. Android, iOS and macOS charge paid calls to the owner's budget
for that package ID. All revisions of a fork share its budget across linked
devices. Independently submitted definitions that reuse an ID also share that
owner's budget. Keep the catalog key for lookup, revision pins and local records.
Publisher identity, withdrawal and deletion behavior must be documented and tested.

### Finding a published edition

Use `GET /v1/templates/catalog?kind=applet&scope=public` for the shared library, or `scope=owned` with an owner credential or linked device for the owner's published editions. Keep the same scope and search when following the returned cursor. Fetch the exact key and revision from the row. The management endpoint `/v1/templates/owned` also lists drafts. An installed edition retains its pinned definition and verified assets offline. When a revision requires an intervening migration, the Apple host offers the next revision separately for owner review.

## Personal editions and updates

On iOS and macOS, open **On this device**, select an installed edition and choose
**Applet settings** to change its declared inputs. Field labels and help come
from `ui.inputs`. Enum values appear as choices. Nested objects, arrays, and
nullable types accept JSON. Save validates the whole configuration against
`config_schema`. Invalid input keeps the previous settings. A stale editor
must reopen the current values. Saved settings belong to that owner's local
installation and take effect when its next flow starts.

For an installed registry edition on iOS or macOS, the owner reviews a newer
revision before applying it. The host checks saved settings against the proposed
schema and writes the package, pin and merged configuration in one SQLite
operation. A stale review must be repeated if the installation changed. The
Apple review lists each added table and column and identifies additions shared
with the installer. An additive revision keeps existing row IDs, photos and
values. Older rows may omit a newly added column until a write sets it.
Changes to an existing column, retention policy or sharing declaration require
a data migration. The Apple host checks that existing table declarations remain compatible and accepts additive changes with an empty migration rule list. It rejects incompatible updates before committing the new pin. A package requiring
a transformation needs a host that implements that rule.

Instance settings do not fork the definition. Personal edits retain a full snapshot,
exact upstream baseline and stable component IDs. Three-way updates compare baseline,
new upstream and personal edition. Conflicts leave the active version running.
New permissions or data sharing require the applicable authority; platform consent
is never manufactured by a manifest. Package activation, schema migration and
scheduler generation must be coordinated with crash recovery. Restoring a manifest
does not undo external actions or recover deleted rows without actual data backup.

## Dog Monitor conversion

The 1.5.0 edition remains addressable at revision 6. Published revision 7 (2.0.0) in
`applets/dog-monitor/applet.json` declares its camera and sound
classifiers, budgets, episode rules, foreground checks and controls as data.
Camera and sound watches each start paused and have separate start controls. Starting the sound watch permits a bowl photo after a confident eating or drinking episode. The Android host takes a primary monitoring camera and up to seven additional phone lenses or enrolled LAN camera IDs. The foreground camera is configured independently. A private fork can declare a conditional capability in `permissions.optional`. Android derives its effective grants from the configured plan and requires owner approval when an update first adds one. Dog Monitor uses this for `lan_camera`, so using only phone lenses grants no network camera access. Its interval and hourly cap are shared, and it compares each lens only with its own previous frames. Each label can trigger one check per ten minutes, subject to the flow and applet budgets. The same bowl check runs on demand or after the evening meal deadline. It reports only what the selected camera shows.
Android and Apple use the same Clef questions for a foreground photo. Observation rows retain the activity, confidence, dog presence probability and observed mood. Clef receives choice and probability questions. The legacy Jev-only bounding-box question is excluded from these calls.
Scheduled watches require a compatible paired host.

Before migrating an Android installation, the owner can open its activity
section and choose **Export local Dog Monitor history**. The Android share
sheet offers a JSON document tagged `bridgit-dog-monitor-history/1`. It
identifies the source instance, edition digest, time zone and sampling interval.
The `tracker` object preserves the full saved episode and coverage arrays, day
counts and the last 60 observations. Replaying those observations alone would
lose older episodes. The document also carries sound tallies, available sound
observations, the feeding position, sensor selections, and the latest cached JPEG
when present. Viewer credentials and server-held recordings stay in their
original account. A snapshot taken during monitoring can have different latest
timestamps for sound and camera. Treat each timestamp independently.

On the same Android installation, an edition change from the legacy adapter to
`bridgit.package.v1` with `migration.strategy = explicit_owner_opt_in` requires
owner review. Approval retains the instance ID, development journal, previous
configuration, budget identity and limits. The review carries the native sampling interval from milliseconds into seconds, rounding a fraction up. An explicit interval selected during review takes precedence. The host stages a new applet principal,
stops the tracker, and saves its private history before activating the portable
edition paused. The first applet resume enables its foreground flows. Camera
and sound watches have separate start controls. A retry after interruption
reconciles the staged principal against the installed edition. If the old portal
was enabled, **Open existing Pet monitor gallery** opens the original device
and applet on the signed-in site. Apple lists the original galleries already
accessible to the signed-in account. The server continues enforcing its owner
and viewer roles. A history import grants no gallery access.

To transfer a file to another Android installation, open the portable edition and select **Import local Dog Monitor
history** in its activity section. On iOS and macOS, open the installed edition,
then **Imported Dog Monitor history** and **Choose exported history**. Select
the JSON file (up to 8 MiB). The device saves the original document privately
for that installation and displays its recorded episodes. Importing the same
file again is safe. A different file cannot overwrite the existing archive.
Removing the installation deletes its copy. Importing an archive does not
start a sensor, transfer a viewer grant, or apply an old feeding position to a
new camera enrollment.

A fresh installation selects revision 7. An existing installation stays on its
previous pin until its owner reviews the migration. The review identifies
differences from the old tracker, including its automatic camera selection,
roaming pan search and alternative models. The portable monitor uses the reviewed
camera list, named bowl position and Clef classifiers. The Android device check
upgraded a populated fixture, preserved its selected microphone and bowl
position, and rejected access after revocation or camera re-enrollment.

## Release gates

- All current applets are registry packages; no APK/Apple bundle definitions/assets.
- Android, iOS and macOS pass the same package/flow/service conformance corpus.
- Real runs prove the converted applets' capture, analysis, actions, pause, resume,
  data inspection/export, settings preservation and behavior when offline.
- Personal edition/upstream integration preserves history and reports conflicts.
- Catalog tests cover 10,000 entries, full pagination, literal search, visibility,
  ownership, forks, signed-device reads and draft isolation.
- Asset tests cover hash/size/type checks, authorization, missing/corrupt objects,
  reference retention, concurrent upload/collection, and offline installation.
- The standalone authoring kit includes the complete versioned schema, reference,
  service snapshot, working examples and offline validator. An LLM-generated
  package validates and runs without undocumented corrections.
- Required PR checks pass; backend migration/deployment and all affected builds
  are verified before claiming release completion. Android publication uses the
  existing shared Alpuca coordinator, not a competing APK publisher.

### Named positions on monitoring cameras

A photo step may declare a portable position name, for example
`{"id":"shot","type":"photo","camera":{"$input":"bowl_camera"},"view":"bowl"}`.
Use a lower-case letter followed by up to 31 lower-case letters, digits or underscores.
Front and rear lenses take an ordinary photo. A filled `lan:` camera selection requires
an enrolled Android monitoring host and an owner-reviewed `lan_camera` capability.
The host moves only to its own saved position for that instance, confirms arrival and
Stop, then captures. Owner-started checks show a shutter and require photo acceptance.
Apple foreground checks use the built-in lens. Choose a paired monitoring host for LAN PTZ.

Owners can choose **Saved camera positions** from the installed applet menu.
On the monitoring host the authenticated applet editor with applet-install and LAN camera
access reads `GET /v1/lan-cameras/applet-views/{instance}/{view}`. Aim the camera first.
In Fixer Mode, POST an empty object to save its current position, or POST the exact
returned `revision` to replace it. DELETE with the revision query parameter to clear it.
A conflict requires another GET. Up to eight named positions belong to one instance.
Credentials and enrollment proofs stay on that host. After enrolling a replacement
camera or importing on another device, save a position there before running the step.


### Microphones for sound watches

Set `request.sound.sources` to a list containing `builtin` and up to four distinct
enrolled LAN camera IDs. An omitted list uses the built-in microphone. An empty list
leaves the watch without a microphone. A choice of camera microphones requires both
`lan_camera` and `lan_camera_audio`. Declare them in `permissions.optional` when
the source is configurable. A paid classifier shares its hourly limit across the
selected microphones. Each reading identifies its source and another microphone's
answer cannot classify the clip by reuse. Dog Monitor carries the owner's selected
microphones into the conversion review. Start the sound watch explicitly after conversion.

## Run mode and task state

Packages may declare `run_mode` as `autonomous` or `passive`. Autonomous
packages start work from watches, schedules or device events. Passive packages
start work on explicit requests. Validation rejects declarations that contradict
known triggers. Older packages derive their mode from their processing definition.

The installed API returns a separate `lifecycle` with `task_id`, `generation`,
`state`, `participants` and `pending`. States are `starting`, `running`,
`pausing` and `paused`. The existing authenticated pause endpoint changes this
task. It persists the transition before stopping resources and records each
acknowledgment. Failed resources stay pending and appear in `lifecycle_errors`.
Repeat the pause request to retry. Resume waits until pause completes.

Pause cancels the task's watches, scheduled jobs and workflow executions, waits
for cleanup, and stops its speaker output. Saved camera-view and native Pet
Monitor movement retain exclusive ownership until the enrolled camera
acknowledges Stop. Unconfirmed Stop records survive restart. Restart resumes
unfinished transitions. Explicit manual actions remain available after pause
completes, under their existing permissions, without resuming monitoring.
